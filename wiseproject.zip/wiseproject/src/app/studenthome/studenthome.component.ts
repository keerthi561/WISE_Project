import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-studenthome',
  templateUrl: './studenthome.component.html',
  styleUrls: ['./studenthome.component.css']
})
export class StudenthomeComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit() {
  }
  private attendence() : void{
    this.router.navigate(['/student-attendence'])
  }
  private project() : void{
      this.router.navigate(['/studproject'])
  }

}
