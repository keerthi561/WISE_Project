import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class TrainerService {
  flag: boolean;
  constructor(private httpClient: HttpClient) {}
  setUserLoggedIn() {
    this.flag = true;
  }
  getUserLogged(): boolean {
    return this.flag;
  }
  setUserLoggedOut() {
    this.flag = false;
  }
  getTrainerByUserId(userId: string): any {
    return this.httpClient.get('RestAPI/webapi/TrainerResource/getTrainerByUserId/' + userId).toPromise();
  }

}
