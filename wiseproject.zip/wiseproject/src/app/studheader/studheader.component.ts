import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-studheader',
  templateUrl: './studheader.component.html',
  styleUrls: ['./studheader.component.css']
})
export class StudheaderComponent implements OnInit {

  constructor(private router :Router, private service: StudentService) { }

  ngOnInit() {
  }
  logOut()
 {
   this.service.setUserLoggedOut();
   this.router.navigate(['login']);
 }
}
