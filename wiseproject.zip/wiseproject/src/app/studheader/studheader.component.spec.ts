import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StudheaderComponent } from './studheader.component';

describe('StudheaderComponent', () => {
  let component: StudheaderComponent;
  let fixture: ComponentFixture<StudheaderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StudheaderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StudheaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
