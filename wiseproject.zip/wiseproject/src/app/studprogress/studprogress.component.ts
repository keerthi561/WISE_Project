import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-studprogress',
  templateUrl: './studprogress.component.html',
  styleUrls: ['./studprogress.component.css']
})
export class StudprogressComponent implements OnInit {

  bar: any;
  constructor() {
    this.bar = [{percentage:98,Heading:"Attendance",bgcolor:"rgb(121, 50, 168)"},
                {percentage:80,Heading:"Scoremore ",bgcolor:"rgb(100, 17, 155)"},
                {percentage:55,Heading:"InClassPerformance",bgcolor:"#a406ff"},
                {percentage:44,Heading:"DailyDose",bgcolor:"#bd3ef8"},
                {percentage:90,Heading:"Hackathon",bgcolor:"rgb(212, 108, 243)"},
                {percentage:80,Heading:"ProjectEuler",bgcolor:"rgb(210, 124, 245)"},
                {percentage:50,Heading:"CodingPlatforms",bgcolor:"#e59ffa"},
                {percentage:82,Heading:"MCQs",bgcolor:"#eed3f8"}]
   }

  ngOnInit() {
  }

}
