import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StudprogressComponent } from './studprogress.component';

describe('StudprogressComponent', () => {
  let component: StudprogressComponent;
  let fixture: ComponentFixture<StudprogressComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StudprogressComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StudprogressComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
