import { Component, OnInit,ViewChild  } from '@angular/core';
import { CSVRecord } from './CSVModel';
import { StudentService } from '../student.service';
@Component({
  selector: 'app-csv',
  templateUrl: './csv.component.html',
  styleUrls: ['./csv.component.css']
})
export class CsvComponent implements OnInit {

  title = 'Angular7-readCSV';

  constructor(private service: StudentService) { }

  records = [];
  @ViewChild('csvReader', {static: false}) csvReader: any;

  uploadListener($event: any): void {

    let text = [];
    let files = $event.srcElement.files;

    

    if (this.isValidCSVFile(files[0])) {

      let input = $event.target;
      let reader = new FileReader();
      reader.readAsText(input.files[0]);

      reader.onload = () => {
        let csvData = reader.result;
        let csvRecordsArray = (<string>csvData).split(/\r\n|\n/);

        let headersRow = this.getHeaderArray(csvRecordsArray);

        this.records = this.getDataRecordsArrayFromCSVFile(csvRecordsArray, headersRow.length);
        var jsonArray = JSON.parse(JSON.stringify(this.records));
        //console.log(jsonArray[0]);
        this.service.registerStud(jsonArray).subscribe();
      };

      reader.onerror = function () {
        console.log('error is occured while reading file!');
      };

    } else {
      alert("Please import valid .csv file.");
      this.fileReset();
    }
  }

  getDataRecordsArrayFromCSVFile(csvRecordsArray: any, headerLength: any) {
    let csvArr = [];

    for (let i = 1; i < csvRecordsArray.length; i++) {
      let curruntRecord = (<string>csvRecordsArray[i]).split(',');
      if (curruntRecord.length == headerLength) {
        let csvRecord: CSVRecord = new CSVRecord();
        csvRecord.studentId = curruntRecord[0].trim();
        csvRecord.studentName = curruntRecord[1].trim();
        csvRecord.studentUserId= curruntRecord[2].trim();
        csvRecord.studentPassword = curruntRecord[3].trim();
        csvRecord.studentDOB = curruntRecord[4].trim();
        csvRecord.studentDept = curruntRecord[5].trim();
        csvRecord.studentMobile = curruntRecord[6].trim();
        csvRecord.studentClg = curruntRecord[7].trim();
        csvRecord.studentSection = curruntRecord[8].trim();
        csvRecord.homeAddress = curruntRecord[9].trim();
        csvRecord.pincode = curruntRecord[10].trim();
        csvRecord.city = curruntRecord[11].trim();
        csvRecord.district = curruntRecord[12].trim();
        csvRecord.state = curruntRecord[13].trim();
        csvRecord.country = curruntRecord[14].trim();
        csvRecord.studentFb = curruntRecord[15].trim();
        csvRecord.studentLinkedIn = curruntRecord[16].trim();
        csvRecord.studentGit = curruntRecord[17].trim();
        csvArr.push(csvRecord);
      }
    }
    return csvArr;
  }

  isValidCSVFile(file: any) {
    return file.name.endsWith(".csv");
  }

  getHeaderArray(csvRecordsArr: any) {
    let headers = (<string>csvRecordsArr[0]).split(',');
    let headerArray = [];
    for (let j = 0; j < headers.length; j++) {
      headerArray.push(headers[j]);
    }
    return headerArray;
  }

  fileReset() {
    this.csvReader.nativeElement.value = "";
    this.records = [];
  }
  ngOnInit() {
  }

}
