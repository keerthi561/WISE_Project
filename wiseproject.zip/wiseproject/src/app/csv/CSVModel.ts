export class CSVRecord {
    studentId: any;
    studentName: any;
    studentUserId: any;
    studentPassword: any;
    studentDOB: any;
    studentDept: any;
    studentMobile: any;
    studentClg: any;
    studentSection: any;
    homeAddress: any;
    pincode: any;
    city: any;
    district: any;
    state: any;
    country: any;
    studentFb: any;
    studentLinkedIn: any;
    studentGit: any;
  }
  
