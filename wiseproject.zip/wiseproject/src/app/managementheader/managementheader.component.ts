import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-managementheader',
  templateUrl: './managementheader.component.html',
  styleUrls: ['./managementheader.component.css']
})
export class ManagementheaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
