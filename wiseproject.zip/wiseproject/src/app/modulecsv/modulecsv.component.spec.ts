import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModulecsvComponent } from './modulecsv.component';

describe('ModulecsvComponent', () => {
  let component: ModulecsvComponent;
  let fixture: ComponentFixture<ModulecsvComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModulecsvComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModulecsvComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
