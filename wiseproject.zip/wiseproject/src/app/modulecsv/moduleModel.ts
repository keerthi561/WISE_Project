export class CSVRecord {
    modId: any;
    modName: any;
    modDuration: any;
    modStartDate: any;
    modEndDate: any;
    projectNum: any;
    projectName: any;
    
  }