import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-attendence',
  templateUrl: './attendence.component.html',
  styleUrls: ['./attendence.component.css']
})
export class AttendenceComponent implements OnInit {
  
  forms:any;
  url = 'assets/js/attendence.js';
  loadAPI: Promise<any>;

  constructor(private router: Router) {
    this.forms = [
    
    
    { heading: "Date of absent",icons:"fas fa-calendar",width:"0%"},
    { heading: "Re-Joining Date",icons:"fas fa-calendar",width:"0%"},
    ]
   }

  ngOnInit() {
    this.loadAPI = new Promise(resolve => {
      this.loadScript();
    });
  }
  public loadScript() {
    let node = document.createElement('script');
    node.src = this.url;
    node.type = 'text/javascript';
    node.async = true;
    node.charset = 'utf-8';
    document.getElementsByTagName('head')[0].appendChild(node);
}

}
