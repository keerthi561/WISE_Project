import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ManagementService {
  flag: boolean;
  // managementId : any;
  managementUserId: any;
  constructor(private httpClient: HttpClient) {
    // this.managementUserId = "123456@tsteam.com";
   }
  setUserLoggedIn() {
    this.flag = true;
  }
  setManagementUserId(managementUserId : string) {
    this.managementUserId = managementUserId;
  }
  getManagementUserId() {
    return this.managementUserId;
  }
  getUserLogged(): boolean {
    return this.flag;
  }
  setUserLoggedOut() {
    this.flag = false;
  }
  
  getManagementByUserId(userId: string): any {
    console.log("service"+ userId);
    return this.httpClient.get('RestAPI2/webapi/ManagementResource/getManagementByUserId/' + userId).toPromise();
  }
  // registerStud(records: any) {
  //   console.log(records);
  //   return this.httpClient.post('RestAPI2/webapi/myresource/registerStudent', records);
  // }
  registerManagement(records: any) {
    console.log(records);
    return this.httpClient.post('RestAPI2/webapi/myresource/registerManagement', records);
  }

  // getManagementById(managementId : any) {
  //   return this.httpClient.get('RestAPI2/webapi/myresource/getManagementById/'+ managementId);
  // }


}
