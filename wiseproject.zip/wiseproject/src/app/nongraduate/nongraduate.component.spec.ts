import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NongraduateComponent } from './nongraduate.component';

describe('NongraduateComponent', () => {
  let component: NongraduateComponent;
  let fixture: ComponentFixture<NongraduateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NongraduateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NongraduateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
