import { Component, OnInit, ViewChild } from '@angular/core';
import { CSVRecord } from './CSVModel';
// import { StudentService } from '../student.service';
import { ManagementService } from '../management.service';

@Component({
  selector: 'app-managementcsv',
  templateUrl: './managementcsv.component.html',
  styleUrls: ['./managementcsv.component.css']
})
export class ManagementcsvComponent implements OnInit {

  title = 'Angular7-readCSV';

  constructor(private service: ManagementService) { }

  records = [];
  @ViewChild('csvReader', {static: false}) csvReader: any;

  uploadListener($event: any): void {

    let text = [];
    let files = $event.srcElement.files;

    

    if (this.isValidCSVFile(files[0])) {

      let input = $event.target;
      let reader = new FileReader();
      reader.readAsText(input.files[0]);

      reader.onload = () => {
        let csvData = reader.result;
        let csvRecordsArray = (<string>csvData).split(/\r\n|\n/);

        let headersRow = this.getHeaderArray(csvRecordsArray);

        this.records = this.getDataRecordsArrayFromCSVFile(csvRecordsArray, headersRow.length);
        var jsonArray = JSON.parse(JSON.stringify(this.records));
        //console.log(jsonArray[0]);
        this.service.registerManagement(jsonArray).subscribe();
      };

      reader.onerror = function () {
        console.log('error is occured while reading file!');
      };

    } else {
      alert("Please import valid .csv file.");
      this.fileReset();
    }
  }

  getDataRecordsArrayFromCSVFile(csvRecordsArray: any, headerLength: any) {
    let csvArr = [];

    for (let i = 1; i < csvRecordsArray.length; i++) {
      let curruntRecord = (<string>csvRecordsArray[i]).split(',');
      if (curruntRecord.length == headerLength) {
        let csvRecord: CSVRecord = new CSVRecord();
        csvRecord.managementId = curruntRecord[0].trim();
        csvRecord.managementName = curruntRecord[1].trim();
        csvRecord.managementDesignation= curruntRecord[2].trim();
        csvRecord.managementUserId = curruntRecord[3].trim();
        csvRecord.managementPassword = curruntRecord[4].trim();
        csvRecord.managementMobile = curruntRecord[5].trim();
        csvRecord.homeAddress = curruntRecord[6].trim();
        csvRecord.pincode = curruntRecord[7].trim();
        csvRecord.city = curruntRecord[8].trim();
        csvRecord.district = curruntRecord[9].trim();
        csvRecord.state = curruntRecord[10].trim();
        csvRecord.country = curruntRecord[11].trim();
        csvRecord.managementImage = curruntRecord[12].trim();
        csvRecord.managementGender = curruntRecord[13].trim();
        csvRecord.managementFb = curruntRecord[14].trim();
        csvRecord.managementTwitter = curruntRecord[15].trim();
        csvRecord.managementLinkedIn = curruntRecord[16].trim();
        
        csvArr.push(csvRecord);
      }
    }
    return csvArr;
  }

  isValidCSVFile(file: any) {
    return file.name.endsWith(".csv");
  }

  getHeaderArray(csvRecordsArr: any) {
    let headers = (<string>csvRecordsArr[0]).split(',');
    let headerArray = [];
    for (let j = 0; j < headers.length; j++) {
      headerArray.push(headers[j]);
    }
    return headerArray;
  }

  fileReset() {
    this.csvReader.nativeElement.value = "";
    this.records = [];
  }
  ngOnInit() {
  }

}
