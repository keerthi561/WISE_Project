export class CSVRecord {
    managementId: any;
	  managementName: any;
	  managementDesignation: any;
	  managementUserId: any;
	  managementPassword: any;
	  managementMobile: any;
	  homeAddress: any;
	  pincode: any;
	  city: any;
	  district: any;
	  state: any;
	  country: any;
	  managementImage: any;
	  managementGender: any;
	  managementFb: any;
	  managementTwitter: any;
	  managementLinkedIn: any;
  }