import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManagementcsvComponent } from './managementcsv.component';

describe('ManagementcsvComponent', () => {
  let component: ManagementcsvComponent;
  let fixture: ComponentFixture<ManagementcsvComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManagementcsvComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManagementcsvComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
