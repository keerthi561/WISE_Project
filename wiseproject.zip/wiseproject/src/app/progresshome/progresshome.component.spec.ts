import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProgresshomeComponent } from './progresshome.component';

describe('ProgresshomeComponent', () => {
  let component: ProgresshomeComponent;
  let fixture: ComponentFixture<ProgresshomeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProgresshomeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProgresshomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
