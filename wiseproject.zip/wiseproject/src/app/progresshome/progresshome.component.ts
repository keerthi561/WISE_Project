import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-progresshome',
  templateUrl: './progresshome.component.html',
  styleUrls: ['./progresshome.component.css']
})
export class ProgresshomeComponent implements OnInit {
  Module:any;
  currentModule:any;
  progress:any;
  Python:any;
  cl:any;


  constructor(private router: Router) { 
    
    this.Module = [{year :"Module 1"} ,
                  { year:"Module 2"},
                  { year:"Module 3"},
                  { year:"Module 4"},
                  { year:"Module 5"},
                  { year:"Module 6"}
    ]
    this.Python = [{percentage:82,Heading:"Attendance",bgcolor:"rgb(121, 50, 168)"},
                {percentage:80,Heading:"Scoremore ",bgcolor:"rgb(100, 17, 155)"},
                {percentage:55,Heading:"InClassPerformance",bgcolor:"#a406ff"},
                {percentage:40,Heading:"DailyDose",bgcolor:"#bd3ef8"},
                {percentage:95,Heading:"Hackathon",bgcolor:"rgb(212, 108, 243)"},
                {percentage:80,Heading:"ProjectEuler",bgcolor:"rgb(210, 124, 245)"},
                {percentage:50,Heading:"CodingPlatforms",bgcolor:"#e59ffa"},
                {percentage:82,Heading:"MCQs",bgcolor:"#eed3f8"}
  ]
  this.cl = [{percentage:82,Heading:"Attendance",bgcolor:"rgb(121, 50, 168)"},
                {percentage:80,Heading:"Scoremore ",bgcolor:"rgb(100, 17, 155)"},
                {percentage:55,Heading:"InClassPerformance",bgcolor:"#a406ff"},
                {percentage:40,Heading:"DailyDose",bgcolor:"#bd3ef8"},
                {percentage:95,Heading:"Hackathon",bgcolor:"rgb(212, 108, 243)"},
                {percentage:80,Heading:"ProjectEuler",bgcolor:"rgb(210, 124, 245)"},
                {percentage:50,Heading:"CodingPlatforms",bgcolor:"#e59ffa"},
                {percentage:82,Heading:"MCQs",bgcolor:"#eed3f8"}
  ]
}          
    

  

  ngOnInit() {
  }
  private prog(f:any) : void{
      if(f.year = "Module 1"){
     this.router.navigate(['/studprogress'])
     }else {
    this.router.navigate(['/studprogress'])
     }
}

}
