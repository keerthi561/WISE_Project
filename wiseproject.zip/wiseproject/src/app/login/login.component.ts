import { Component, OnInit } from '@angular/core';
import { StudentService } from '../student.service';
import { Router } from '@angular/router';
import { TrainerService } from '../trainer.service';
import { HomeService } from '../home.service';
import { ManagementService } from '../management.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  user: any;
  employee: any;
  student: any;
  management: any;
  validation: string;
  constructor(private router: Router,private service: HomeService, private studentService: StudentService, private trainerService: TrainerService, private managementService: ManagementService) { 
      this.user = {loginId: '', password: ''};
  }

  ngOnInit() {
  }

  async validateUser() {
    
    
    if (this.user.loginId === 'admin') {
      this.service.setUserLoggedIn();
      this.router.navigate(['admin']);
    }
    else if (this.user.loginId.substring(22,6)  === 'talentsprint.com') {
     
      //await this.trainerService.getTrainerByUserId(this.user.loginId).then((data: any) => {
       // this.employee = data; console.log('Inside subscribe');
       //});
      this.service.setUserLoggedIn();
      this.router.navigate(['trainerhome']);
    } else if (this.user.loginId.substring(32,26) === 'edu.in') {
      await this.studentService.getStudentByUserId(this.user.loginId).then((data: any) => {
        this.student = data; console.log('Inside subscribe');
       });
      this.service.setUserLoggedIn();
      this.studentService.setStudId(this.student.studentId);
      this.router.navigate(['studenthome']);
    
      /*if (this.user.password === this.student.studentPassword) {
        this.router.navigate(['studenthome']);
      } else {
        this.validation = "Enter valid credentials";
      }*/ 
    
    } else {
     if(this.user.loginId.substring(6, 17) === '@tsteam.com') {
       this.managementService.getManagementByUserId(this.user.loginId).then((data: any) => {
        this.management = data; console.log("login.ts" + this.user.loginId);
       });
      // this.managementService.getManagementByUserId(this.user.loginId).subscribe(data => this.management = data);
       if (this.management != null) {
        if (this.user.password === this.management.managementPassword) {
          this.service.setUserLoggedIn();
          this.managementService.setManagementUserId(this.management.managementUserId);
          this.router.navigate(['frontpage']);
        } else {
          console.log("Wrong Password")
        }
       } else {
         console.log("Wrong username")
       }
    } else if(this.user.loginId === 'Collegewelcome@admin:~/Desktop/wise project/wiseproject$ Team') {
      this.service.setUserLoggedIn();
      this.router.navigate(['frontpage']);
    } else {
      console.log('Invalid User Credentials..');
     } 
   }
 }

}
