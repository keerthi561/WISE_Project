import { Component, OnInit } from '@angular/core';
import { ManagementService } from '../management.service';

@Component({
  selector: 'app-managementprofile',
  templateUrl: './managementprofile.component.html',
  styleUrls: ['./managementprofile.component.css']
})
export class ManagementprofileComponent implements OnInit {
  management: any;
  managementUserId: any;
  constructor(private managementService: ManagementService) {
    this.managementUserId = this.managementService.getManagementUserId();
  }

  ngOnInit() {
    // this.managementService.getManagementByUserId(this.managementUserId).subscribe(data => { console.log(data); this.management = data; },
    //     (error: any) => console.log('Error Occurred..', error));
    this.managementService.getManagementByUserId(this.managementUserId).then((data: any) => {
          this.management = data; console.log(data);
         });
  
  }

}
