import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManagementprofileComponent } from './managementprofile.component';

describe('ManagementprofileComponent', () => {
  let component: ManagementprofileComponent;
  let fixture: ComponentFixture<ManagementprofileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManagementprofileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManagementprofileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
