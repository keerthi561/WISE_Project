import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StuddiscussionComponent } from './studdiscussion.component';

describe('StuddiscussionComponent', () => {
  let component: StuddiscussionComponent;
  let fixture: ComponentFixture<StuddiscussionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StuddiscussionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StuddiscussionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
