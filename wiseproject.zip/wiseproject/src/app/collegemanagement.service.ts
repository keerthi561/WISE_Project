import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CollegemanagementService {

  flag: boolean;
  id : any;
  userId: any;
  constructor(private httpClient: HttpClient) {
    // this.managementUserId = "123456@tsteam.com";
   }
  setUserLoggedIn() {
    this.flag = true;
  }
  setCollegeManagementUserId(userId : string) {
    this.userId = userId;
  }
  getCollegeManagementUserId() {
    return this.userId;
  }
  getUserLogged(): boolean {
    return this.flag;
  }
  setUserLoggedOut() {
    this.flag = false;
  }
  
  getCollegeManagementByUserId(userId: string): any {
    console.log("service"+ userId);
    return this.httpClient.get('RestAPI2/webapi/ManagementResource/getCollegeManagementByUserId/' + userId).toPromise();
  }
  // registerStud(records: any) {
  //   console.log(records);
  //   return this.httpClient.post('RestAPI2/webapi/myresource/registerStudent', records);
  // }
  registerCollegeManagement(records: any) {
    console.log(records);
    return this.httpClient.post('RestAPI2/webapi/myresource/registerCollegeManagement', records);
  }

  // getCollegeManagementById(managementId : any) {
  //   return this.httpClient.get('RestAPI2/webapi/myresource/getCollegeManagementById/'+ id);
  // }



}
