import { TestBed } from '@angular/core/testing';

import { CollegemanagementService } from './collegemanagement.service';

describe('CollegemanagementService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CollegemanagementService = TestBed.get(CollegemanagementService);
    expect(service).toBeTruthy();
  });
});
