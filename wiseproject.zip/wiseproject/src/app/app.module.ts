import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { TrainerhomeComponent } from './trainerhome/trainerhome.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { LoginComponent } from './login/login.component';
import { RouterModule, Routes } from '@angular/router';
import { ProjectComponent } from './project/project.component';
import { HttpClientModule } from '@angular/common/http';
import { ProfileComponent } from './profile/profile.component';
import { ProgressComponent } from './progress/progress.component';
import { DiscussionComponent } from './discussion/discussion.component';
import { StudenthomeComponent } from './studenthome/studenthome.component';
import { AttendenceComponent } from './attendence/attendence.component';
import { IntroComponent } from './intro/intro.component';
import { NgCircleProgressModule } from 'ng-circle-progress';
import { StudprojectComponent } from './studproject/studproject.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { StudsidebarComponent } from './studsidebar/studsidebar.component';
import { StudprofileComponent } from './studprofile/studprofile.component';
import { StudprogressComponent } from './studprogress/studprogress.component';
import { CalendarComponent } from './calendar/calendar.component';
import { StuddiscussionComponent } from './studdiscussion/studdiscussion.component';
import { StudheaderComponent } from './studheader/studheader.component';
import { FrontpageComponent } from './frontpage/frontpage.component';
import { GraduatedComponent } from './graduated/graduated.component';
import { NongraduateComponent } from './nongraduate/nongraduate.component';
import { ManagementprofileComponent } from './managementprofile/managementprofile.component';
import { ManagementheaderComponent } from './managementheader/managementheader.component';
import { ProgresshomeComponent } from './progresshome/progresshome.component';
import { CsvComponent } from './csv/csv.component';
import { ManagementcsvComponent } from './managementcsv/managementcsv.component';
import { ModulecsvComponent } from './modulecsv/modulecsv.component';
import { AdminComponent } from './admin/admin.component';
import { CollegemanagementcsvComponent } from './collegemanagementcsv/collegemanagementcsv.component';

const appRoot: Routes = [
{path: '', component: LoginComponent},
{path: 'login', component: LoginComponent},
{path: 'studenthome', component: StudenthomeComponent},
{path: 'trainerhome', component: TrainerhomeComponent},
{path: 'profile', component: ProfileComponent},
{path: 'discussion', component: DiscussionComponent},
{path: 'progress', component: ProgressComponent},
{path: 'project', component: ProjectComponent},
{path:'attendence', component :AttendenceComponent},
{path:'studenthome', component :StudenthomeComponent},
{path:'studproject', component :StudprojectComponent},
{path:'studdiscussion', component :StuddiscussionComponent},
{path:'studprofile', component :StudprofileComponent},
{path:'calendar',component :CalendarComponent},
{path:'managementheader',component : ManagementheaderComponent},
{path:'graduated',component : GraduatedComponent},
{path:'nongraduate',component : NongraduateComponent},
{path:'managementprofile',component : ManagementprofileComponent},
{path: 'progresshome', component: ProgresshomeComponent},
{ path: 'studprogress', component:  StudprogressComponent},
{path : 'frontpage', component: FrontpageComponent},
{path : 'csv', component: CsvComponent},
{path : 'managementcsv', component: ManagementcsvComponent},
{path : 'admin', component: AdminComponent},
{path : 'modulecsv', component: ModulecsvComponent},
{path: 'collegemanagementcsv', component: CollegemanagementcsvComponent},
{
  path: 'trainerhome',
  component: TrainerhomeComponent,
  children: [
    { path: 'profile', component: ProfileComponent}, 
    { path: 'discussion', component: DiscussionComponent},
    { path: 'progress', component: ProgressComponent},
    { path: 'project', component: ProjectComponent},
  ]
},
{
  path: 'studhome',
  component: StudenthomeComponent,
  children: [
    { path: 'studprofile', component: ProfileComponent}, 
    {path: 'progresshome', component: ProgresshomeComponent},
    { path: 'attendence', component: AttendenceComponent},
    {path:'studdiscussion', component :StuddiscussionComponent},
    {path:'calendar',component :CalendarComponent},
    {path:'studproject', component :StudprojectComponent},

  ]
},
{
  path: 'frontpage',
  component: FrontpageComponent,
  children: [
    
    { path: 'managementprofile', component: ManagementprofileComponent}, 
    { path: 'graduated', component:  GraduatedComponent},
    { path: 'nongraduate', component: NongraduateComponent}
  ]
},
{
  path: 'admin',
  component: AdminComponent,
  children: [
    {path: 'managementcsv', component: ManagementcsvComponent},
    {path: 'collegemanagementcsv', component: CollegemanagementcsvComponent},
    {path: 'modulecsv', component: ModulecsvComponent}
  ]
}

];

@NgModule({
  declarations: [
    AppComponent,
    TrainerhomeComponent,
    HeaderComponent,
    FooterComponent,
    LoginComponent,
    ProjectComponent,
    ProfileComponent,
    ProgressComponent,
    DiscussionComponent,
    StudenthomeComponent,
    AttendenceComponent,
    IntroComponent,
    StudprojectComponent,
    SidebarComponent,
    StudsidebarComponent,
    StudprofileComponent,
    StudprogressComponent,
    CalendarComponent,
    StuddiscussionComponent,
    StudheaderComponent,
    FrontpageComponent,
    GraduatedComponent,
    NongraduateComponent,
    ManagementprofileComponent,
    ManagementheaderComponent,
    ProgresshomeComponent,
    CsvComponent,
    ManagementcsvComponent,
    ModulecsvComponent,
    AdminComponent,
    CollegemanagementcsvComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot(appRoot),
    RouterModule.forChild(appRoot),
    AppRoutingModule,
    NgCircleProgressModule.forRoot({
      radius: 100,
      outerStrokeWidth: 16,
      innerStrokeWidth: 8,
      outerStrokeColor: "#78C000",
      innerStrokeColor: "#C7E596",
      animationDuration: 300,
    })
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
