import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class StudentService {
  flag: boolean;
  studentId : any;
  constructor(private httpClient: HttpClient) {}
  setUserLoggedIn() {
    this.flag = true;
  }
  setStudId(studId : string) {
    this.studentId = studId;
  }
  getStudId() {
    return this.studentId;
  }
  getUserLogged(): boolean {
    return this.flag;
  }
  setUserLoggedOut() {
    this.flag = false;
  }
  
  getStudentByUserId(userId: string): any {
    return this.httpClient.get('RestAPI2/webapi/StudentResource/getStudentByUserId/' + userId).toPromise();
  }
  registerStud(records: any) {
    console.log(records);
    return this.httpClient.post('RestAPI2/webapi/myresource/registerStudent', records);
  }
  registerManagement(records: any) {
    console.log(records);
    return this.httpClient.post('RestAPI2/webapi/myresource/registerManagement', records);
  }


  getStudentById(studId : any) {
    return this.httpClient.get('RestAPI2/webapi/myresource/getStudentById/'+ studId);
  }

}
