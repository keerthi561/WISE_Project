import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-graduated',
  templateUrl: './graduated.component.html',
  styleUrls: ['./graduated.component.css']
})
export class GraduatedComponent implements OnInit {

  modules: any;
  i: any;
  noOfGraduatedStudents : any;
  constructor() { 
    this.i = 0;
    this.modules= [ {id:this.i+1,name:"WISE - Professional C Programming",startDate:"28/19/2017",endDate:"28/19/2017",promoted:360},
    {id:this.i+2,name:"WISE-Modern Programming - Python",startDate:"28/19/2017",endDate:"28/19/2017",promoted:260}, 
    {id:this.i+3,name:"Everyone Can Code",startDate:"28/19/2017",endDate:"28/19/2017",promoted:200},
    {id:this.i+4,name:"Advanced Java",startDate:"28/19/2017",endDate:"28/19/2017",promoted:300},
    {id:this.i+5,name:"Angular",startDate:"28/19/2017",endDate:"28/19/2017",promoted:170},
    {id:this.i+6,name:"Code Practices",startDate:"28/19/2017",endDate:"28/19/2017",promoted:100}];

    this.noOfGraduatedStudents= 100;
  }


  ngOnInit() {
  }

}
