import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class HomeService {
  flag: boolean;
  constructor(private httpClient: HttpClient) {}
  setUserLoggedIn() {
    this.flag = true;
  }
  getUserLogged(): boolean {
    return this.flag;
  }
  setUserLoggedOut() {
    this.flag = false;
  }
 
}
