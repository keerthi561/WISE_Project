import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StudprofileComponent } from './studprofile.component';

describe('StudprofileComponent', () => {
  let component: StudprofileComponent;
  let fixture: ComponentFixture<StudprofileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StudprofileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StudprofileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
