import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-studprofile',
  templateUrl: './studprofile.component.html',
  styleUrls: ['./studprofile.component.css']
})
export class StudprofileComponent implements OnInit {
  studId: any;
  student: any;

  constructor(private router: Router, private service : StudentService) {
    this.studId = "";
    this.student = [{studentId: ""},
                    {studentName: ""},
                    {studentUserId: ""},
                    {studentPassword: ""},
                    {studentDOB: ""},
                    {studentDept: ""},
                    {studentMobile: ""},
                    {studentClg: ""},
                    {studentSection: ""},
                    {homeAddress: ""},
                    {pincode: ""},
                    {city: ""},
                    {district: ""},
                    {state: ""},
                    {country: ""},
                    {studentFb: ""},
                    {studentLinkedIn: ""},
                    {studentGit: ""}
    ] 
   }

  ngOnInit() {
    this.studId = this.service.getStudId();
    this.service.getStudentById(this.studId).subscribe(data => this.student = data);
  }
  private attendence() : void{
    this.router.navigate(['/student-attendence'])
  }
}
