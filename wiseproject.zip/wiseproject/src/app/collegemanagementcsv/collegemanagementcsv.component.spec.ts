import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CollegemanagementcsvComponent } from './collegemanagementcsv.component';

describe('CollegemanagementcsvComponent', () => {
  let component: CollegemanagementcsvComponent;
  let fixture: ComponentFixture<CollegemanagementcsvComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CollegemanagementcsvComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CollegemanagementcsvComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
