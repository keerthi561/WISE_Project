import { Component, OnInit, ViewChild } from '@angular/core';
// import { CSVRecord } from '../managementcsv/CSVModel';
import { CollegemanagementService } from '../collegemanagement.service';
import { CSVRecord } from './CSVModels';

@Component({
  selector: 'app-collegemanagementcsv',
  templateUrl: './collegemanagementcsv.component.html',
  styleUrls: ['./collegemanagementcsv.component.css']
})
export class CollegemanagementcsvComponent implements OnInit {


  title = 'Angular7-readCSV';

  constructor(private service: CollegemanagementService) { }

  records = [];
  @ViewChild('csvReader', {static: false}) csvReader: any;

  uploadListener($event: any): void {

    let text = [];
    let files = $event.srcElement.files;

    

    if (this.isValidCSVFile(files[0])) {

      let input = $event.target;
      let reader = new FileReader();
      reader.readAsText(input.files[0]);

      reader.onload = () => {
        let csvData = reader.result;
        let csvRecordsArray = (<string>csvData).split(/\r\n|\n/);

        let headersRow = this.getHeaderArray(csvRecordsArray);

        this.records = this.getDataRecordsArrayFromCSVFile(csvRecordsArray, headersRow.length);
        var jsonArray = JSON.parse(JSON.stringify(this.records));
        //console.log(jsonArray[0]);
        this.service.registerCollegeManagement(jsonArray).subscribe();
      };

      reader.onerror = function () {
        console.log('error is occured while reading file!');
      };

    } else {
      alert("Please import valid .csv file.");
      this.fileReset();
    }
  }

  getDataRecordsArrayFromCSVFile(csvRecordsArray: any, headerLength: any) {
    let csvArr = [];

    for (let i = 1; i < csvRecordsArray.length; i++) {
      let curruntRecord = (<string>csvRecordsArray[i]).split(',');
      if (curruntRecord.length == headerLength) {
        let csvRecord: CSVRecord = new CSVRecord();
        csvRecord.id = curruntRecord[0].trim();
        csvRecord.name = curruntRecord[1].trim();
        csvRecord.designation= curruntRecord[2].trim();
        csvRecord.userId = curruntRecord[3].trim();
        csvRecord.password = curruntRecord[4].trim();
        csvRecord.mobile = curruntRecord[5].trim();
        csvRecord.homeAddress = curruntRecord[6].trim();
        csvRecord.pincode = curruntRecord[7].trim();
        csvRecord.city = curruntRecord[8].trim();
        csvRecord.district = curruntRecord[9].trim();
        csvRecord.state = curruntRecord[10].trim();
        csvRecord.country = curruntRecord[11].trim();
        csvRecord.image = curruntRecord[12].trim();
        csvRecord.gender = curruntRecord[13].trim();
        csvRecord.fb = curruntRecord[14].trim();
        csvRecord.twitter = curruntRecord[15].trim();
        csvRecord.linkedIn = curruntRecord[16].trim();
        csvRecord.college = curruntRecord[17].trim();
        csvArr.push(csvRecord);
      }
    }
    return csvArr;
  }

  isValidCSVFile(file: any) {
    return file.name.endsWith(".csv");
  }

  getHeaderArray(csvRecordsArr: any) {
    let headers = (<string>csvRecordsArr[0]).split(',');
    let headerArray = [];
    for (let j = 0; j < headers.length; j++) {
      headerArray.push(headers[j]);
    }
    return headerArray;
  }

  fileReset() {
    this.csvReader.nativeElement.value = "";
    this.records = [];
  }
  ngOnInit() {
  }

}
