export class CSVRecord {
	id: any;
	name: any;
	designation: any;
	userId: any;
	password: any;
	mobile: any;
	homeAddress: any;
	pincode: any;
	city: any;
	district: any;
	state: any;
	country: any;
	image: any;
	gender: any;
	fb: any;
	twitter: any;
	linkedIn: any;
	college: any;
  }