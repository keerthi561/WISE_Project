import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-progress',
  templateUrl: './progress.component.html',
  styleUrls: ['./progress.component.css']
})
export class ProgressComponent implements OnInit {

  bar: any;
  constructor() {
    this.bar = [{percentage:100,Heading:"Attendance"},
                {percentage:80,Heading:"Scoremore"},
                {percentage:55,Heading:"InClassPerformance"},
                {percentage:40,Heading:"DailyDose"},
          
  ]
}

  ngOnInit() {
  }

}
