import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-studproject',
  templateUrl: './studproject.component.html',
  styleUrls: ['./studproject.component.css']
})
export class StudprojectComponent implements OnInit {

  projects:any;

  constructor() {
    this.projects = [{ imagePath: 'assets/Python.png',info: "python-project",Name:"Puzzle",gitlink:"https//xxx"},
                     { imagePath: "assets/Java.png ",info: "java-project",Name:"login",gitlink:"https//xxx"}]
   }

  ngOnInit() {
  }

}
