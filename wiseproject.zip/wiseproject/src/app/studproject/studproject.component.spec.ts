import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StudprojectComponent } from './studproject.component';

describe('StudprojectComponent', () => {
  let component: StudprojectComponent;
  let fixture: ComponentFixture<StudprojectComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StudprojectComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StudprojectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
