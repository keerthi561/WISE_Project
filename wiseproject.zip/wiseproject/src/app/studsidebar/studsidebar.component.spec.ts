import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StudsidebarComponent } from './studsidebar.component';

describe('StudsidebarComponent', () => {
  let component: StudsidebarComponent;
  let fixture: ComponentFixture<StudsidebarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StudsidebarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StudsidebarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
