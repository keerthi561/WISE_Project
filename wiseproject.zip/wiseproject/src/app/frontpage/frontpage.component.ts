import { Component, OnInit } from '@angular/core';
import { RouterModule } from '@angular/router';
import { Router } from '@angular/router';
import { ManagementService } from '../management.service';
import { StudentService } from '../student.service';
@Component({
  selector: 'app-frontpage',
  templateUrl: './frontpage.component.html',
  styleUrls: ['./frontpage.component.css']
})
export class FrontpageComponent implements OnInit {

  currentData : any;
  currentYear : any;
  graduatedData : any;

  constructor(private router: Router, private managementService: ManagementService, private studentService: StudentService) {
    
    this.currentYear=2019;
    this.graduatedData={year:this.currentYear-4,noOfStudents:102};
    this.currentData=[
      {year:this.currentYear-3,noOfStudents:102},
      {year:this.currentYear-2,noOfStudents:210},
      {year:this.currentYear-1,noOfStudents:300},
      {year:this.currentYear,noOfStudents:360}];

  }

  ngOnInit() {
  }
  checkYear(current:any) {
    // this.currentData.currentYear=2059;
    //current.year=2016;
    

    if (current.year < this.currentYear-3 ) {
      this.router.navigate(['graduated']);
    } else {
      this.router.navigate(['nongraduate']);
    }
  }

}
